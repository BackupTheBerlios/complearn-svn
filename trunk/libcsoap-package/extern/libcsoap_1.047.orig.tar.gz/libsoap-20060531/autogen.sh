#!/bin/sh

aclocal
autoconf
automake --add-missing --copy
automake

