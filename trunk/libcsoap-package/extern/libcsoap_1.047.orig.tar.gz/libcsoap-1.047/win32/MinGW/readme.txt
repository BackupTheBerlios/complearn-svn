 wine wcmd /c compile.bat
